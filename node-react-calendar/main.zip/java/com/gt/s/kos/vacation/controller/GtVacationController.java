package com.gt.s.kos.vacation.controller;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.transform.impl.AddDelegateTransformer;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.gt.s.common.ChabunUtil;
import com.gt.s.common.CommonUtils;
import com.gt.s.common.DateFormatUtil;
import com.gt.s.common.FileUploadUtil;
import com.gt.s.common.K_Session;
import com.gt.s.common.chabun.service.GtChabunService;
import com.gt.s.kos.employee.service.GtEmployeeService;
import com.gt.s.kos.employee.vo.GtEmployeeVO;
import com.gt.s.kos.vacation.service.GtVacationService;
import com.gt.s.kos.vacation.vo.GtVacationVO;

@Controller
public class GtVacationController {
	
	Logger log = LogManager.getLogger(this.getClass());
	
	private String chabun;
	
	@Autowired(required = false)
	private GtVacationService gtVacationService;
	
	@Autowired(required = false)
	private GtChabunService gtChabunService;
	
	@Autowired(required = false)
	private GtEmployeeService gtEmployeeService;
	Process pro = null;
	@GetMapping("gtVacationChanbun")
	@ResponseBody
	public String gtVacationChanbun() {
		
		log.info("test >> :");
		
		String gbt_num = ChabunUtil.BIZ_GUBUN_VA.concat(DateFormatUtil.ymdFormats("D")).concat(gtChabunService.getGtVacationChabun().getGvnum());
		
		return gbt_num;
	}
	
	  @PostMapping("gtVacationInsertFile") // < 파일을 먼저 넣는다. public String
	  public String gtVacationInsertFile(@RequestParam("gvfile") ArrayList<MultipartFile> files) { // 함수는 xml 연결
		  
		  
		  log.info("gtVacationFileupload > : 진입");
		  
		  String fileNames = FileUploadUtil.fileupload(files, this.chabun, CommonUtils.SP_FILE_UPLOAD_PATH);
			log.info("fileNames > : " + fileNames);
			GtVacationVO vvo = null;
			vvo = new GtVacationVO();
			vvo.setGvnum(this.chabun);
			vvo.setGvfile(fileNames);
			log.info("vvo.getGvnum() > : " + vvo.getGvnum());
			log.info("vvo.getGvfile() > : " + vvo.getGvfile());
			
			log.info(vvo.getGvnum());
		  
		  int nCnt = gtVacationService.gtVacationInsertFile(vvo);
		  
		  if(nCnt > 0) { 
			  	return "vacation/vacationInsert";
		  
		  }else {
			  	return "vacation/fail";
		  }
		  
	  }
	  
		/*
		 * @GetMapping(value = "fileDownloadlist", produces =
		 * "application/x-www-form-urlencoded;charset=UTF-8")
		 * 
		 * @ResponseBody public String fileDownloadList(HttpServletRequest q) {
		 * 
		 * String num = q.getParameter("gvnum"); String reString = ""; // 폴더에 있는 전체 파일
		 * 목록 가져오기 File path = new File(CommonUtils.SP_FILE_UPLOAD_PATH + "//" + num);
		 * String[] fileList = path.list(); for(int i=0; i<fileList.length; i++) {
		 * reString += fileList[i] + ","; }
		 * 
		 * return reString;
		 * 
		 * } // 파일 다운로드 처리
		 * 
		 * @GetMapping(value = "fileDownload") public void fileDownload(@RequestParam
		 * String file, @RequestParam String num, HttpServletResponse s,
		 * HttpServletRequest q) { s.setContentType("text/html; charset=UTF-8");
		 * log.info("file > : " + file); log.info("gvnum > : " + num);
		 * 
		 * boolean b = FileUploadUtil.filedownload(s, q, num, file);
		 * 
		 * log.info("b > : " + b); }
		 */
	 
	
	@GetMapping("gtVacationSelectAll")
	public String gtVacationSelectAll(HttpServletRequest req, Model m, GtVacationVO vvo) {
		
		List<GtVacationVO> aList = gtVacationService.gtVacationSelectAll(vvo);
		
		if(aList.size() > 0) {
			

			m.addAttribute("aList", aList);
			return "vacation/vacationSelectAll";
		}else {
			return "vacation/fail";
		}
			
	}
	
	@GetMapping("gtVacationSelect")
	public String gtVacationSelect(HttpServletRequest req, Model m, GtVacationVO vvo) {
		
		
			
		vvo.getGvnum(); 
		log.info("로그 >> : " + vvo.getGvnum());
		List<GtVacationVO> aList = gtVacationService.gtVacationSelect(vvo);
		
		if(aList.size() > 0) {
			
			m.addAttribute("aList", aList);
			return "vacation/vacationSelect";
		}else {
			return "vacation/fail";
		}
		
	}
	
	@GetMapping("gtVacationUpdate")
	public String gtVacationUpdate(HttpServletRequest req, Model m, GtVacationVO vvo) {
			
			vvo.getGvnum(); 
		
			log.info("로그 >> : " + vvo.getGvnum());

			List<GtVacationVO> aList = gtVacationService.gtVacationSelect(vvo);
			
			aList.get(0).getGvreasons();
			aList.get(0).getGvsubject();
			log.info("로그 >> : " + aList.get(0).getGvreasons());
			log.info("로그 >> : " + aList.get(0).getGvsubject());
			if(aList.size() > 0) {
				
				m.addAttribute("aList", aList);
				return "vacation/vacationUpdate";
			}else {
				return "vacation/fail";
			}
			
		}
		
	

		@GetMapping("gtVacationDelete") 
		public String gtVacationDelete(HttpServletRequest req, GtVacationVO vvo) {
			
			int nCnt = gtVacationService.gtVacationDelete(vvo);
			
			if(nCnt > 0) {
				return "vacation/vacationDelete";
				
			}else {
				return "vacation/fail";
				
			}
		}

	
	@GetMapping("gtVacationInsert")
	@ResponseBody
	public String gtVacationInsert(GtVacationVO vvo, HttpServletRequest req) {
		
		log.info("chabunInsert 진입 > ㅣ:");
		
		this.chabun = null;
		
		this.chabun = vvo.getGvnum();
		
		// VO에 이름이 없어서 req/getParameter해서 값을 세팅해줬다.
		String gvapprover1 = req.getParameter("approver1");
		String gvapprover2 = req.getParameter("approver2");
		String gvapprover3 = req.getParameter("approver3");
		String gvapprover4 = req.getParameter("approver4");
		String gvapprover5 = req.getParameter("approver5");
		// String gehp = req.getParameter("gehp");
		

		String gvapprover = gvapprover1 + "/" + gvapprover2 + "/" + gvapprover3 + "/" + gvapprover4 + "/" + gvapprover5;
		
		log.info(gvapprover);
		String gvdept1 = req.getParameter("dep1");
		String gvdept2 = req.getParameter("dep2");
		String gvdept3 = req.getParameter("dep3");
		String gvdept4 = req.getParameter("dep4");
		String gvdept5 = req.getParameter("dep5");
		
		String gvdetp = gvdept1 + "/" + gvdept2 + "/" + gvdept3 + "/" + gvdept4 + "/" + gvdept5;
		
		String gvwriter = req.getParameter("writer");
		log.info(gvwriter);

		
		// 연락처
		String gvgehp = req.getParameter("gehp");
		log.info("연락처 > : " + gvgehp);
		

		vvo.setApprover(gvapprover);
		vvo.setDept(gvdetp);

		log.info(" >>> : " + gvapprover);
		log.info(" >>> : " + gvdetp);
		
		// 제목, 사유, 구분, 비고
		String gvsubject = vvo.getGvsubject();
		String gvreasons = vvo.getGvreasons();
		String gvtype = vvo.getGvtype();
		String gvmemo = vvo.getGvmemo();
		String gvdays = vvo.getGvdays();
		
		log.info("제목 > : " + gvsubject);
		log.info("사유 > : " + gvreasons);
		log.info("구분 > : " + gvtype);
		log.info("비고 > : " + gvmemo);
		log.info("기간 > : " + gvdays);
		
		
		
		// String 변수 명= vvo.get가져오고싶은 값();
		int nCnt = gtVacationService.gtVacationInsert(vvo);
		
		log.info("nCnt : " + nCnt);

		if(nCnt > 0) {
			// ajax return은 return에 사용한 값이 나옴
			// 원래는 return에 view 페이지 명을 찾아서 갔었음
			
			return "OK";
			
		}else {
			
			return "NO";
		}
		
		
		
	}
	
	@GetMapping("gtVacationInsertForm")
	// @ResponseBody <<< ajax에서만 쓰는거
	public String gtVacationInsertForm(HttpServletRequest q, GtVacationVO vvo, Model m, GtEmployeeVO evo) {
		
		K_Session ks = K_Session.getInstance();
		String genum = ks.getSession(q);
		
		
		if(genum != null) {
			evo.setGenum(genum);
			evo = gtEmployeeService.gecheck(evo);
			String gename = evo.getGedept() + " " + evo.getGename() + " " + evo.getTitle();
			String gehp = evo.getGehp();
			String title = evo.getTitle();
			
			
			log.info(gename);
			log.info(evo.getGename());
			log.info(evo.getGedept());
			log.info(evo.getTitle());
			log.info(evo.getGehp());
			
			m.addAttribute("title", title);
			m.addAttribute("gename", gename);
			m.addAttribute("gehp", gehp);
			m.addAttribute("genum", genum);
			
			
			return "vacation/vacationInsertForm";
		}else {
			return "vacation/fail";
		}
		
	
	}
	
}
