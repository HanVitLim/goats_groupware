package com.gt.s.kos.plan.dao;

import com.gt.s.kos.plan.vo.GtPlanVO;

public interface GtPlanDAO {

	
	public int gtPlanInsert(GtPlanVO pvo);
}
