package com.gt.s.kos.plan.service;

import com.gt.s.kos.plan.vo.GtPlanVO;

public interface GtPlanService {

	public int gtPlanInsert(GtPlanVO pvo);
}
