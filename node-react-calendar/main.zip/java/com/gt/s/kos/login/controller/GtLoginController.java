package com.gt.s.kos.login.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.gt.s.common.K_Session;
import com.gt.s.kos.employee.service.GtEmployeeService;
import com.gt.s.kos.employee.vo.GtEmployeeVO;
import com.gt.s.kos.login.service.GtLoginService;

@Controller
public class GtLoginController {
	
	Logger log = LogManager.getLogger(this.getClass());

	@Autowired(required = false)
	private GtLoginService loginService; // 로그인과 관련된 비즈니스 로직을 처리하는 서비스 클래스

	@Autowired(required = false)
	private GtEmployeeService gtEmployeeService; // 사원 정보와 관련된 비즈니스 로직을 처리하는 서비스 클래스
	
	@GetMapping(value = "loginForm")
	public String loginForm() {
		return "login/loginForm"; // 로그인 화면을 보여주는 뷰 페이지로 이동
	}
	
	@GetMapping(value = "loginx")
	public String loginx() {
		return "login/loginX"; // 로그인 실패 시 보여줄 뷰 페이지로 이동
	}
	
	@PostMapping(value = "login")
	public String login(GtEmployeeVO evo, HttpServletRequest q, Model m) {
		// 사용자가 입력한 아이디와 비밀번호를 받아서 로그인 처리하는 메서드
		
		System.out.println(evo.getGeid());
		System.out.println(evo.getGepw());
		
		List<GtEmployeeVO> list = loginService.logincheck(evo); // 로그인 정보를 검증하고 사용자 정보를 리스트로 받아옴
		if(list != null && list.size() > 0) {
			log.info("list.size() > : " + list.size());
			if(list.size() == 1) { // 검증된 사용자 정보가 1개일 경우
				
				K_Session ks = K_Session.getInstance(); // K_Session 유틸리티 클래스의 인스턴스를 가져옴
				String kID = ks.getSession(q); // 현재 세션에서 KID 값을 가져옴
				log.info("kID는 어떤 값이 나오는가 >>>> " + kID);
				evo = gtEmployeeService.genumcheck(evo); // 사용자 정보에서 genum 값을 가져옴
				
				if (kID != null && kID.equals(evo.getGenum())) {	
					// 현재 세션에 이미 genum 값이 저장되어 있고, 로그인한 사용자의 genum과 같다면
					log.info("KosmoLoginController login >>> : 로그인 중 >>> : 메인 페이지로 이동 하기 >>> : " + kID);
					m.addAttribute("listLogin", list);
					return "login/loginOK"; // 로그인 성공 시 보여줄 뷰 페이지로 이동
				} else {
					ks.setSession(q, evo.getGenum()); // 현재 세션에 genum 값을 저장함 (세션 부여)
					log.info("KosmoLoginController login >>> : 세션부여 하기  >>> : " + evo.getGenum());
					
					m.addAttribute("listLogin", list);
					return "login/loginOK"; // 로그인 성공 시 보여줄 뷰 페이지로 이동
				}
			}
		}
		return "login/loginfail"; // 로그인 실패 시 보여줄 뷰 페이지로 이동
	}
	
	@GetMapping(value = "logincheck", produces = "application/x-www-form-urlencoded;charset=UTF-8")
	@ResponseBody
	public String logincheck(HttpServletRequest q, GtEmployeeVO evo) {
		// 로그인 상태를 확인하는 메서드
		
		K_Session ks = K_Session.getInstance(); // K_Session 유틸리티 클래스의 인스턴스를 가져옴
		String genum = ks.getSession(q); // 현재 세션에서 genum 값을 가져옴
		if(genum != null) {
			evo.setGenum(genum); // 가져온 genum 값을 GtEmployeeVO 객체에 설정
			String gename = gtEmployeeService.goatempidcheck(evo).getGename(); // 사용자 정보를 가져와서 이름을 얻어옴
			
			return gename; // 사용자 이름을 반환 (Ajax 호출에 사용됨)
		} else {
			return "loginx"; // 로그인되지 않았을 경우 "loginx"를 반환 (Ajax 호출에 사용됨)
		}
	}
	
	@GetMapping(value = "logout")
	public String logout(HttpServletRequest q) {
		// 로그아웃 처리하는 메서드
		
		K_Session ks = K_Session.getInstance(); // K_Session 유틸리티 클래스의 인스턴스를 가져옴
		
		ks.killSession(q); // 현재 세션 무효화 (로그아웃)
		
		return "login/logout"; // 로그아웃 시 보여줄 뷰 페이지로 이동
	}
}