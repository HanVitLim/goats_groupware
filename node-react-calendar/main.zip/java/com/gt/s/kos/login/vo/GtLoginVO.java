package com.gt.s.kos.login.vo;

public class GtLoginVO {

}
