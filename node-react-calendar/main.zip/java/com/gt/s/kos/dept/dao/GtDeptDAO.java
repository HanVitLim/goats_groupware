package com.gt.s.kos.dept.dao;

import java.util.List;

import com.gt.s.kos.dept.vo.GtDeptVO;


public interface GtDeptDAO {
	
	public List<GtDeptVO> goatsDeptSelectAll();
	
}
