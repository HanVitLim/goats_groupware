package com.gt.s.kos.dept.service;

import java.util.List;

import com.gt.s.kos.dept.vo.GtDeptVO;




public interface GtDeptService {

	public List<GtDeptVO> goatsDeptSelectAll();
	
	
} // end of interface
