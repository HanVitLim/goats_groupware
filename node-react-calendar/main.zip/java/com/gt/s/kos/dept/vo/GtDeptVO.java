package com.gt.s.kos.dept.vo;

public class GtDeptVO {
	
	private String deptno;
	private String deptname;
	private String insertdate;
	private String updatedate;
	private String deleteyn;
	
	public GtDeptVO() {
		
		// TODO Auto-generated constructor stub
	}
	
	public GtDeptVO(String deptno, String deptname, String insertdate, String updatedate, String deleteyn) {
		
		this.deptno = deptno;
		this.deptname = deptname;
		this.insertdate = insertdate;
		this.updatedate = updatedate;
		this.deleteyn = deleteyn;
	}

	public String getDeptno() {
		return deptno;
	}

	public void setDeptno(String deptno) {
		this.deptno = deptno;
	}

	public String getDeptname() {
		return deptname;
	}

	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}

	public String getInsertdate() {
		return insertdate;
	}

	public void setInsertdate(String insertdate) {
		this.insertdate = insertdate;
	}

	public String getUpdatedate() {
		return updatedate;
	}

	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}

	public String getDeleteyn() {
		return deleteyn;
	}

	public void setDeleteyn(String deleteyn) {
		this.deleteyn = deleteyn;
	}
	
	
	
} // end of class
