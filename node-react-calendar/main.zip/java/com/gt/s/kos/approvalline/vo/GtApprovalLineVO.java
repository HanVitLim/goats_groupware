package com.gt.s.kos.approvalline.vo;

public class GtApprovalLineVO {
	
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count, String tablename, String numname, String apryn, String app, String subjectname,
			String insertdate, String deciwriter) {
		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
		this.tablename = tablename;
		this.numname = numname;
		this.apryn = apryn;
		this.app = app;
		this.subjectname = subjectname;
		this.insertdate = insertdate;
		this.deciwriter = deciwriter;
	}
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count, String tablename, String numname, String apryn, String app, String subjectname,
			String insertdate) {
		
		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
		this.tablename = tablename;
		this.numname = numname;
		this.apryn = apryn;
		this.app = app;
		this.subjectname = subjectname;
		this.insertdate = insertdate;
	}
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count, String tablename, String numname, String apryn, String app, String subjectname) {
		
		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
		this.tablename = tablename;
		this.numname = numname;
		this.apryn = apryn;
		this.app = app;
		this.subjectname = subjectname;
	}
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count, String tablename, String numname, String apryn, String app) {
		
		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
		this.tablename = tablename;
		this.numname = numname;
		this.apryn = apryn;
		this.app = app;
	}
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count, String tablename, String numname, String apryn) {
	
		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
		this.tablename = tablename;
		this.numname = numname;
		this.apryn = apryn;
	}
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count, String tablename, String numname) {
		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
		this.tablename = tablename;
		this.numname = numname;
	}
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count, String tablename) {
		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
		this.tablename = tablename;
	}
	public GtApprovalLineVO() {

	}
	public GtApprovalLineVO(String gename, String appnum, String subject, String writer, String date, String approver,
			String count) {

		this.gename = gename;
		this.appnum = appnum;
		this.subject = subject;
		this.writer = writer;
		this.date = date;
		this.approver = approver;
		this.count = count;
	}
	private String gename;
	private String appnum;
	private String subject;
	private String writer;
	private String date;
	private String approver;
	private String count;
	private String tablename;
	private String numname;
	private String apryn;
	private String app;
	private String subjectname;
	private String insertdate;
	private String deciwriter;
	public String getGename() {
		return gename;
	}
	public String getAppnum() {
		return appnum;
	}
	public String getSubject() {
		return subject;
	}
	public String getWriter() {
		return writer;
	}
	public String getDate() {
		return date;
	}
	public String getApprover() {
		return approver;
	}
	public String getCount() {
		return count;
	}
	public void setGename(String gename) {
		this.gename = gename;
	}
	public void setAppnum(String appnum) {
		this.appnum = appnum;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public void setDate(String date) {
		this.date = date;
	}
	public void setApprover(String approver) {
		this.approver = approver;
	}
	public void setCount(String count) {
		this.count = count;
	}
	public String getTablename() {
		return tablename;
	}
	public void setTablename(String tablename) {
		this.tablename = tablename;
	}
	public String getNumname() {
		return numname;
	}
	public void setNumname(String numname) {
		this.numname = numname;
	}
	public String getApryn() {
		return apryn;
	}
	public void setApryn(String apryn) {
		this.apryn = apryn;
	}
	public String getApp() {
		return app;
	}
	public void setApp(String app) {
		this.app = app;
	}
	public String getSubjectname() {
		return subjectname;
	}
	public void setSubjectname(String subjectname) {
		this.subjectname = subjectname;
	}
	public String getInsertdate() {
		return insertdate;
	}
	public void setInsertdate(String insertdate) {
		this.insertdate = insertdate;
	}
	public String getDeciwriter() {
		return deciwriter;
	}
	public void setDeciwriter(String deciwriter) {
		this.deciwriter = deciwriter;
	}
} // end of VO
