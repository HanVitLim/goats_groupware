package com.gt.s.kos.contract.vo;

public class GtContractVO {
	public GtContractVO() {
	}
	public GtContractVO(String gcnum, String gcsubject, String gcsalplace, String gcpurchase, String gccontent,
			String gcconform, String gcsalitem, String gcsalquantity, String gcsalamount, String gcpuritem,
			String gcpuramount, String gcattach, String gcsign, String gcfile, String insertdate, String updatedate,
			String deleteyn, String genum, String writer, String reference, String approver, String dept, String proval,
			String count) {
		this.gcnum = gcnum;
		this.gcsubject = gcsubject;
		this.gcsalplace = gcsalplace;
		this.gcpurchase = gcpurchase;
		this.gccontent = gccontent;
		this.gcconform = gcconform;
		this.gcsalitem = gcsalitem;
		this.gcsalquantity = gcsalquantity;
		this.gcsalamount = gcsalamount;
		this.gcpuritem = gcpuritem;
		this.gcpuramount = gcpuramount;
		this.gcattach = gcattach;
		this.gcsign = gcsign;
		this.gcfile = gcfile;
		this.insertdate = insertdate;
		this.updatedate = updatedate;
		this.deleteyn = deleteyn;
		this.genum = genum;
		this.writer = writer;
		this.reference = reference;
		this.approver = approver;
		this.dept = dept;
		this.proval = proval;
		this.count = count;
	}
	private String gcnum;
	private String gcsubject;
	private String gcsalplace;
	private String gcpurchase;
	private String gccontent;
	private String gcconform;
	private String gcsalitem;
	private String gcsalquantity;
	private String gcsalamount;
	private String gcpuritem;
	private String gcpuramount;
	private String gcattach;
	private String gcsign;
	private String gcfile;
	private String insertdate;
	private String updatedate;
	private String deleteyn;
	private String genum;
	private String writer;
	private String reference;
	private String approver;
	private String dept;
	private String proval;
	private String count;
	public String getGcnum() {
		return gcnum;
	}
	public String getGcsubject() {
		return gcsubject;
	}
	public String getGcsalplace() {
		return gcsalplace;
	}
	public String getGcpurchase() {
		return gcpurchase;
	}
	public String getGccontent() {
		return gccontent;
	}
	public String getGcconform() {
		return gcconform;
	}
	public String getGcsalitem() {
		return gcsalitem;
	}
	public String getGcsalquantity() {
		return gcsalquantity;
	}
	public String getGcsalamount() {
		return gcsalamount;
	}
	public String getGcpuritem() {
		return gcpuritem;
	}
	public String getGcpuramount() {
		return gcpuramount;
	}
	public String getGcattach() {
		return gcattach;
	}
	public String getGcsign() {
		return gcsign;
	}
	public String getGcfile() {
		return gcfile;
	}
	public String getInsertdate() {
		return insertdate;
	}
	public String getUpdatedate() {
		return updatedate;
	}
	public String getDeleteyn() {
		return deleteyn;
	}
	public String getGenum() {
		return genum;
	}
	public String getWriter() {
		return writer;
	}
	public String getReference() {
		return reference;
	}
	public String getApprover() {
		return approver;
	}
	public String getDept() {
		return dept;
	}
	public String getProval() {
		return proval;
	}
	public String getCount() {
		return count;
	}
	public void setGcnum(String gcnum) {
		this.gcnum = gcnum;
	}
	public void setGcsubject(String gcsubject) {
		this.gcsubject = gcsubject;
	}
	public void setGcsalplace(String gcsalplace) {
		this.gcsalplace = gcsalplace;
	}
	public void setGcpurchase(String gcpurchase) {
		this.gcpurchase = gcpurchase;
	}
	public void setGccontent(String gccontent) {
		this.gccontent = gccontent;
	}
	public void setGcconform(String gcconform) {
		this.gcconform = gcconform;
	}
	public void setGcsalitem(String gcsalitem) {
		this.gcsalitem = gcsalitem;
	}
	public void setGcsalquantity(String gcsalquantity) {
		this.gcsalquantity = gcsalquantity;
	}
	public void setGcsalamount(String gcsalamount) {
		this.gcsalamount = gcsalamount;
	}
	public void setGcpuritem(String gcpuritem) {
		this.gcpuritem = gcpuritem;
	}
	public void setGcpuramount(String gcpuramount) {
		this.gcpuramount = gcpuramount;
	}
	public void setGcattach(String gcattach) {
		this.gcattach = gcattach;
	}
	public void setGcsign(String gcsign) {
		this.gcsign = gcsign;
	}
	public void setGcfile(String gcfile) {
		this.gcfile = gcfile;
	}
	public void setInsertdate(String insertdate) {
		this.insertdate = insertdate;
	}
	public void setUpdatedate(String updatedate) {
		this.updatedate = updatedate;
	}
	public void setDeleteyn(String deleteyn) {
		this.deleteyn = deleteyn;
	}
	public void setGenum(String genum) {
		this.genum = genum;
	}
	public void setWriter(String writer) {
		this.writer = writer;
	}
	public void setReference(String reference) {
		this.reference = reference;
	}
	public void setApprover(String approver) {
		this.approver = approver;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	public void setProval(String proval) {
		this.proval = proval;
	}
	public void setCount(String count) {
		this.count = count;
	}
	
}
